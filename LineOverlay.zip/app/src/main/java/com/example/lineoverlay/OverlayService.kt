package com.example.lineoverlay

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat

class OverlayService:Service(){
    companion object{const val ACTION_TOGGLE="toggle";const val ACTION_CALIBRATE="calibrate";const val ACTION_STOP="stop";private const val CHANNEL="guide";private const val ID=10}
    private lateinit var wm:WindowManager;private lateinit var canvas:GuideCanvas;private lateinit var circle:CircleView;private lateinit var bubble:BubbleView
    private lateinit var cp:WindowManager.LayoutParams;private var circleOn=true;private var calibrating=false
    override fun onCreate(){super.onCreate();wm=getSystemService(WINDOW_SERVICE) as WindowManager;createChannel();startForeground(ID,NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_compass).setContentTitle("Line Overlay Guide").setContentText("Overlay is running").setOngoing(true).build());canvas=GuideCanvas(this);circle=CircleView(this);bubble=BubbleView(this);addCanvas();addCircle();addBubble();refresh()}
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{when(i?.action){ACTION_TOGGLE->toggle();ACTION_CALIBRATE->startCalibration();ACTION_STOP->stopSelf()};return START_STICKY}
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"Overlay",NotificationManager.IMPORTANCE_LOW))}
    private fun addCanvas(){val p=WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP or Gravity.START;wm.addView(canvas,p)}
    private fun addCircle(){val s=dp(52);val saved=Prefs.circle(this);val d=resources.displayMetrics;val x=saved?.x?:d.widthPixels*.5f;val y=saved?.y?:d.heightPixels*.5f;cp=WindowManager.LayoutParams(s,s,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);cp.gravity=Gravity.TOP or Gravity.START;cp.x=(x-s/2f).toInt();cp.y=(y-s/2f).toInt();wm.addView(circle,cp)}
    private fun addBubble(){val s=dp(48);val p=WindowManager.LayoutParams(s,s,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.TOP or Gravity.END;p.x=dp(12);p.y=dp(90);wm.addView(bubble,p)}
    private fun toggle(){circleOn=!circleOn;refresh()}
    private fun startCalibration(){calibrating=true;circleOn=false;refresh();canvas.startCalibration();val p=canvas.layoutParams as WindowManager.LayoutParams;p.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;wm.updateViewLayout(canvas,p);bubble.enabled=false}
    fun finishCalibration(corners:List<PointF>,pockets:List<PointF>){Prefs.saveCalibration(this,corners,pockets);calibrating=false;val p=canvas.layoutParams as WindowManager.LayoutParams;p.flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;wm.updateViewLayout(canvas,p);circleOn=true;bubble.enabled=true;canvas.finishCalibration();refresh()}
    private fun refresh(){val calibrated=Prefs.isCalibrated(this);canvas.center=center();canvas.visible=circleOn&&calibrated;circle.visibility=if(circleOn&&calibrated&&!calibrating)View.VISIBLE else View.GONE;canvas.invalidate();circle.invalidate()}
    private fun center()=PointF(cp.x+cp.width/2f,cp.y+cp.height/2f)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    inner class GuideCanvas(c:Context):View(c){private val p=Paint(3);private val tp=Paint(3);var center=PointF();var visible=false;private var step=0;private val pts=mutableListOf<PointF>();init{tp.textSize=dp(16).toFloat();tp.typeface=Typeface.DEFAULT_BOLD}
        fun startCalibration(){step=0;pts.clear();invalidate()};fun finishCalibration(){step=0;pts.clear();invalidate()}
        override fun onTouchEvent(e:MotionEvent):Boolean{if(!calibrating)return false;if(e.action==MotionEvent.ACTION_UP){pts.add(PointF(e.x,e.y));step++;if(step==10)finishCalibration(pts.subList(0,4),pts.subList(4,10));invalidate()};return true}
        override fun onDraw(c:Canvas){if(calibrating){p.style=Paint.Style.FILL;p.color=Color.argb(145,0,0,0);c.drawRect(0f,0f,width.toFloat(),height.toFloat(),p);p.color=Color.WHITE;pts.forEach{c.drawCircle(it.x,it.y,dp(8).toFloat(),p)};c.drawRoundRect(dp(18).toFloat(),dp(24).toFloat(),width-dp(18).toFloat(),dp(74).toFloat(),dp(14).toFloat(),dp(14).toFloat(),p);tp.color=Color.BLACK;val t=if(step<4)"Calibration: tap the 4 table corners (${step+1}/4)" else "Now tap the 6 pockets (${step-3}/6)";c.drawText(t,dp(32).toFloat(),dp(56).toFloat(),tp);return};if(!visible)return;val pockets=Prefs.pockets(this@OverlayService);val corners=Prefs.corners(this@OverlayService);if(pockets.size!=6||corners.size!=4)return;p.style=Paint.Style.STROKE;p.strokeWidth=dp(1).toFloat();p.color=Color.argb(105,215,235,245);p.strokeCap=Paint.Cap.ROUND;pockets.forEach{target->val path=Geometry.reflectedPath(center,target,corners);val q=Path();q.moveTo(path[0].x,path[0].y);for(i in 1 until path.size)q.lineTo(path[i].x,path[i].y);c.drawPath(q,p)}}}
    inner class CircleView(c:Context):View(c){private val p=Paint(3);private var dx=0f;private var dy=0f;private var sx=0;private var sy=0;override fun onDraw(c:Canvas){val x=width/2f;val y=height/2f;p.style=Paint.Style.FILL;p.color=Color.argb(35,255,255,255);c.drawCircle(x,y,dp(10).toFloat(),p);p.style=Paint.Style.STROKE;p.strokeWidth=dp(1).toFloat();p.color=Color.argb(150,225,240,245);c.drawCircle(x,y,dp(10).toFloat(),p)}override fun onTouchEvent(e:MotionEvent):Boolean{when(e.actionMasked){MotionEvent.ACTION_DOWN->{dx=e.rawX;dy=e.rawY;sx=cp.x;sy=cp.y;return true};MotionEvent.ACTION_MOVE->{cp.x=sx+(e.rawX-dx).toInt();cp.y=sy+(e.rawY-dy).toInt();wm.updateViewLayout(this,cp);canvas.center=center();canvas.invalidate();return true};MotionEvent.ACTION_UP->{val q=center();Prefs.saveCircle(this@OverlayService,q.x,q.y);return true}};return true}}
    inner class BubbleView(c:Context):TextView(c){init{background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Color.argb(210,20,20,20));setStroke(dp(1),Color.argb(170,230,230,230))};text="◎";textSize=22f;gravity=Gravity.CENTER;setTextColor(Color.WHITE);setOnClickListener{toggle()};setOnLongClickListener{startCalibration();true}}}
    override fun onDestroy(){runCatching{wm.removeView(canvas)};runCatching{wm.removeView(circle)};runCatching{wm.removeView(bubble)};super.onDestroy()}
    override fun onBind(i:Intent?)=null
}
