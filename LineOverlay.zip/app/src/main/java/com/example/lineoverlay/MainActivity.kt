package com.example.lineoverlay

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad=(24*resources.displayMetrics.density).toInt()
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(pad,pad,pad,pad)}
        root.addView(TextView(this).apply{text="Line Overlay Guide";textSize=26f;setPadding(0,0,0,pad/2)})
        root.addView(TextView(this).apply{text="Manual setup: tap the 4 playing-surface corners, then the 6 pockets.\n\nThe floating ◎ button toggles the guide circle. Long-press it to recalibrate.";textSize=16f})
        root.addView(Button(this).apply{text="Start overlay";setOnClickListener{startOverlay(false)}})
        root.addView(Button(this).apply{text="Calibrate table";setOnClickListener{startOverlay(true)}})
        root.addView(Button(this).apply{text="Stop overlay";setOnClickListener{stopService(Intent(this@MainActivity,OverlayService::class.java))}})
        setContentView(root)
    }
    private fun startOverlay(calibrate:Boolean){
        if(!Settings.canDrawOverlays(this)){
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
            Toast.makeText(this,"Allow 'Display over other apps', then tap Calibrate again.",Toast.LENGTH_LONG).show(); return
        }
        ContextCompat.startForegroundService(this,Intent(this,OverlayService::class.java).apply{action=if(calibrate)OverlayService.ACTION_CALIBRATE else null})
        if(calibrate)Toast.makeText(this,"Return to the game. Calibration is ready.",Toast.LENGTH_SHORT).show()
    }
}
