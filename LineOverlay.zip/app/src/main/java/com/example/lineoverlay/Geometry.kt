package com.example.lineoverlay

import android.graphics.PointF
import kotlin.math.abs

object Geometry {
    fun reflectedPath(start: PointF, target: PointF, corners: List<PointF>): List<PointF> {
        if (corners.size != 4) return listOf(start, target)
        val left=corners.minOf{it.x}; val right=corners.maxOf{it.x}
        val top=corners.minOf{it.y}; val bottom=corners.maxOf{it.y}
        val w=right-left; val h=bottom-top
        if(w<=1f || h<=1f) return listOf(start,target)
        var best: List<PointF>? = null
        var bestScore = Int.MAX_VALUE
        for(mx in -3..3) for(my in -3..3) {
            val tx=if(mx%2==0) target.x else left+right-target.x
            val ty=if(my%2==0) target.y else top+bottom-target.y
            val mirrored=PointF(tx+mx*w, ty+my*h)
            val ts=intersections(start,mirrored,left,right,top,bottom)
            if(ts.size<=3) {
                val score=abs(mx)+abs(my)
                if(score<bestScore) { bestScore=score; best=buildPath(start,mirrored,ts,target) }
            }
        }
        return best ?: listOf(start,target)
    }
    private fun intersections(a:PointF,b:PointF,l:Float,r:Float,t:Float,bot:Float):List<Float>{
        val dx=b.x-a.x; val dy=b.y-a.y; val ts=mutableListOf<Float>()
        if(abs(dx)>0.001f) for(x in listOf(l,r)){val q=(x-a.x)/dx; val y=a.y+q*dy; if(q>0&&q<1&&y>=t&&y<=bot)ts.add(q)}
        if(abs(dy)>0.001f) for(y in listOf(t,bot)){val q=(y-a.y)/dy; val x=a.x+q*dx; if(q>0&&q<1&&x>=l&&x<=r)ts.add(q)}
        return ts.distinct().sorted()
    }
    private fun buildPath(a:PointF,b:PointF,ts:List<Float>,target:PointF):List<PointF>{
        val out=mutableListOf(a); for(q in ts) out.add(PointF(a.x+(b.x-a.x)*q,a.y+(b.y-a.y)*q)); out.add(target); return out
    }
}
