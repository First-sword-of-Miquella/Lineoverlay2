# Line Overlay Guide

Android floating overlay with manual calibration, a draggable guide circle, six faint pocket guide paths, and rail reflection paths.

Calibration: tap the four playing-surface corners, then the six pocket centers. Tap the floating ◎ button to hide/show the guide. Long-press it to recalibrate.
